package example;

import client.HelloWorldService;

public class HelloClient {
  public static void main(String[] argv) {
    final HelloWorldService service = new HelloWorldService();
    final String reply = service.getHelloWorldPort().sayHelloWorldFrom("Serge");
    System.out.println("reply = " + reply);
  }
}