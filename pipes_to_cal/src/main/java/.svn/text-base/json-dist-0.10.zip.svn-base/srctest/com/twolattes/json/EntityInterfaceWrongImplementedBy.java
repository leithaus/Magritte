package com.twolattes.json;

@Entity(implementedBy = B.class)
public interface EntityInterfaceWrongImplementedBy {
}
