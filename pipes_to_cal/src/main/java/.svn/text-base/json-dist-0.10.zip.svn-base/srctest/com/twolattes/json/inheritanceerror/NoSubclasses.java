package com.twolattes.json.inheritanceerror;

import com.twolattes.json.Entity;

@Entity(discriminatorName = "type")
public class NoSubclasses {
}
