package com.twolattes.json;

@Entity
public class ArrayEntity {
  @Value
  String[] values = null;
}
