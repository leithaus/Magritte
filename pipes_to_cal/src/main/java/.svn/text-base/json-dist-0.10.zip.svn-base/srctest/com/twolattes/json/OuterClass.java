package com.twolattes.json;

public class OuterClass {
  @Entity
  public static class InnerClass {
    @Value
    String field;
  }
}
