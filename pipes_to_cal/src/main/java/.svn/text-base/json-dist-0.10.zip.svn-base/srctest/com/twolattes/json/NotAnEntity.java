package com.twolattes.json;

public class NotAnEntity {
}
