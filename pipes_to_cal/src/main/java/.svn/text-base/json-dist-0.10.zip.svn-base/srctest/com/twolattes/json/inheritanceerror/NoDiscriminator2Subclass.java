package com.twolattes.json.inheritanceerror;

import com.twolattes.json.Entity;

@Entity
public class NoDiscriminator2Subclass {
}
