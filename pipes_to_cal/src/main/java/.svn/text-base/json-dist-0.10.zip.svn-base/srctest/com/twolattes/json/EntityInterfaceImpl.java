package com.twolattes.json;

public class EntityInterfaceImpl implements EntityInterface {
  boolean whatever;

  public boolean isWhatever() {
    return whatever;
  }

  public void setWhatever(boolean whatever) {
    this.whatever = whatever;
  }
}
