package com.twolattes.json;

@Entity(inline = true)
class EmailInline {
  @Value
  String email;
}
