package com.twolattes.json.inheritanceerror;

import com.twolattes.json.Entity;

@Entity(subclasses = {NoDiscriminatorName.class})
public class NoDiscriminatorName {
}
