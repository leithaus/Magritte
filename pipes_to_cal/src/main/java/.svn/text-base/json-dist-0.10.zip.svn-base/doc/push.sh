#!/bin/sh
scp -r . plperez@shell.sourceforge.net:/home/groups/j/js/jsonmarshaller/htdocs
